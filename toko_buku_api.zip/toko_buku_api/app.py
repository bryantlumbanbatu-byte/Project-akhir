import os
from dotenv import load_dotenv
from decimal import Decimal, InvalidOperation
from flask import Flask, jsonify, request
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import IntegrityError


load_dotenv()

db = SQLAlchemy()

class Category(db.Model):
    __tablename__ = 'categories'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    description = db.Column(db.String(300))
    books = db.relationship('Book', back_populates='category', cascade='all, delete-orphan')
    def to_dict(self): return {'id': self.id, 'name': self.name, 'description': self.description}

class Book(db.Model):
    __tablename__ = 'books'
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    author = db.Column(db.String(150), nullable=False)
    price = db.Column(db.Numeric(12, 2), nullable=False)
    stock = db.Column(db.Integer, nullable=False, default=0)
    category_id = db.Column(db.Integer, db.ForeignKey('categories.id', ondelete='CASCADE'), nullable=False)
    category = db.relationship('Category', back_populates='books')
    order_items = db.relationship('OrderItem', back_populates='book')
    def to_dict(self): return {'id': self.id, 'title': self.title, 'author': self.author, 'price': float(self.price), 'stock': self.stock, 'category_id': self.category_id, 'category': self.category.name if self.category else None}

class Customer(db.Model):
    __tablename__ = 'customers'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    email = db.Column(db.String(200), unique=True, nullable=False)
    phone = db.Column(db.String(30))
    orders = db.relationship('Order', back_populates='customer')
    def to_dict(self): return {'id': self.id, 'name': self.name, 'email': self.email, 'phone': self.phone}

class Order(db.Model):
    __tablename__ = 'orders'
    id = db.Column(db.Integer, primary_key=True)
    customer_id = db.Column(db.Integer, db.ForeignKey('customers.id'), nullable=False)
    status = db.Column(db.String(30), nullable=False, default='pending')
    customer = db.relationship('Customer', back_populates='orders')
    items = db.relationship('OrderItem', back_populates='order', cascade='all, delete-orphan')
    def to_dict(self): return {'id': self.id, 'customer_id': self.customer_id, 'customer': self.customer.name if self.customer else None, 'status': self.status, 'items': [i.to_dict() for i in self.items], 'total': round(sum(float(i.unit_price) * i.quantity for i in self.items), 2)}

class OrderItem(db.Model):
    __tablename__ = 'order_items'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, db.ForeignKey('orders.id', ondelete='CASCADE'), nullable=False)
    book_id = db.Column(db.Integer, db.ForeignKey('books.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    unit_price = db.Column(db.Numeric(12, 2), nullable=False)
    order = db.relationship('Order', back_populates='items')
    book = db.relationship('Book', back_populates='order_items')
    def to_dict(self): return {'id': self.id, 'order_id': self.order_id, 'book_id': self.book_id, 'book_title': self.book.title if self.book else None, 'quantity': self.quantity, 'unit_price': float(self.unit_price), 'subtotal': round(float(self.unit_price) * self.quantity, 2)}


def create_app(test_config=None):
    app = Flask(__name__)
    database_url = os.getenv('DATABASE_URL', 'sqlite:///toko_buku.db')
    if database_url.startswith('postgres://'): database_url = database_url.replace('postgres://', 'postgresql://', 1)
    app.config.update(SQLALCHEMY_DATABASE_URI=database_url, SQLALCHEMY_TRACK_MODIFICATIONS=False, JSON_SORT_KEYS=False)
    if test_config: app.config.update(test_config)
    db.init_app(app)

    @app.get('/')
    def index():
        return jsonify({'message': 'Toko Buku REST API aktif', 'version': '1.0.0', 'docs': '/api/docs', 'resources': ['/categories', '/books', '/customers', '/orders', '/order-items']})

    @app.get('/health')
    def health(): return jsonify({'status': 'ok'})

    @app.get('/api/docs')
    def docs(): return jsonify({'message': 'Dokumentasi API tersedia di README.md dan docs/API.md'})

    def error(message, code): return jsonify({'status': 'error', 'message': message}), code
    def body():
        data = request.get_json(silent=True)
        if not isinstance(data, dict): return None
        return data
    def required(data, fields):
        missing = [f for f in fields if f not in data or data[f] in (None, '')]
        return missing
    def positive_int(value): return isinstance(value, int) and not isinstance(value, bool) and value >= 0

    # Categories
    @app.get('/categories')
    def categories_list(): return jsonify({'data': [x.to_dict() for x in Category.query.order_by(Category.id).all()]})
    @app.post('/categories')
    def categories_create():
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if required(d, ['name']): return error('Field name wajib diisi', 400)
        x = Category(name=str(d['name']).strip(), description=d.get('description'))
        if not x.name: return error('Field name tidak boleh kosong', 400)
        db.session.add(x); return save_and_return(x, 201)
    @app.route('/categories/<int:item_id>', methods=['GET','PUT','PATCH','DELETE'])
    def categories_item(item_id):
        x = db.session.get(Category, item_id)
        if not x: return error('Kategori tidak ditemukan', 404)
        if request.method == 'GET': return jsonify({'data': x.to_dict()})
        if request.method == 'DELETE': db.session.delete(x); db.session.commit(); return jsonify({'message':'Kategori berhasil dihapus'})
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if request.method == 'PUT' and required(d, ['name']): return error('Field name wajib diisi untuk PUT', 400)
        if 'name' in d: x.name = str(d['name']).strip()
        if 'description' in d: x.description = d['description']
        return save_and_return(x)

    # Books: main resource with full CRUD
    @app.get('/books')
    def books_list():
        q = Book.query
        if request.args.get('category_id'):
            try: q = q.filter_by(category_id=int(request.args['category_id']))
            except ValueError: return error('category_id harus berupa angka', 400)
        if request.args.get('q'): q = q.filter(Book.title.ilike(f"%{request.args['q']}%"))
        return jsonify({'data': [x.to_dict() for x in q.order_by(Book.id).all()]})
    @app.post('/books')
    def books_create():
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        miss = required(d, ['title','author','price','stock','category_id'])
        if miss: return error('Field wajib diisi: ' + ', '.join(miss), 400)
        try: price = Decimal(str(d['price'])); cid = int(d['category_id'])
        except (InvalidOperation, ValueError, TypeError): return error('price harus angka dan category_id harus integer', 400)
        if price < 0 or not positive_int(d['stock']): return error('price tidak boleh negatif dan stock harus integer >= 0', 400)
        if not db.session.get(Category, cid): return error('Kategori tidak ditemukan', 404)
        x = Book(title=str(d['title']).strip(), author=str(d['author']).strip(), price=price, stock=d['stock'], category_id=cid)
        if not x.title or not x.author: return error('title dan author tidak boleh kosong', 400)
        return save_and_return(x, 201)
    @app.route('/books/<int:item_id>', methods=['GET','PUT','PATCH','DELETE'])
    def books_item(item_id):
        x = db.session.get(Book, item_id)
        if not x: return error('Buku tidak ditemukan', 404)
        if request.method == 'GET': return jsonify({'data': x.to_dict()})
        if request.method == 'DELETE':
            if OrderItem.query.filter_by(book_id=x.id).first(): return error('Buku sudah tercatat pada pesanan dan tidak dapat dihapus', 409)
            db.session.delete(x); db.session.commit(); return jsonify({'message':'Buku berhasil dihapus'})
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        fields = ['title','author','price','stock','category_id']
        if request.method == 'PUT' and required(d, fields): return error('PUT wajib mengirim semua field: ' + ', '.join(fields), 400)
        if 'title' in d:
            if not str(d['title']).strip(): return error('title tidak boleh kosong', 400)
            x.title = str(d['title']).strip()
        if 'author' in d:
            if not str(d['author']).strip(): return error('author tidak boleh kosong', 400)
            x.author = str(d['author']).strip()
        if 'price' in d:
            try: x.price = Decimal(str(d['price']))
            except (InvalidOperation, ValueError, TypeError): return error('price harus berupa angka', 400)
            if x.price < 0: return error('price tidak boleh negatif', 400)
        if 'stock' in d:
            if not positive_int(d['stock']): return error('stock harus integer >= 0', 400)
            x.stock = d['stock']
        if 'category_id' in d:
            try: cid = int(d['category_id'])
            except (ValueError, TypeError): return error('category_id harus integer', 400)
            if not db.session.get(Category, cid): return error('Kategori tidak ditemukan', 404)
            x.category_id = cid
        return save_and_return(x)

    # Customers
    @app.get('/customers')
    def customers_list(): return jsonify({'data': [x.to_dict() for x in Customer.query.order_by(Customer.id).all()]})
    @app.post('/customers')
    def customers_create():
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if required(d, ['name','email']): return error('Field name dan email wajib diisi', 400)
        x = Customer(name=str(d['name']).strip(), email=str(d['email']).strip().lower(), phone=d.get('phone'))
        return save_and_return(x, 201)
    @app.route('/customers/<int:item_id>', methods=['GET','PUT','PATCH','DELETE'])
    def customers_item(item_id):
        x = db.session.get(Customer, item_id)
        if not x: return error('Pelanggan tidak ditemukan', 404)
        if request.method == 'GET': return jsonify({'data': x.to_dict()})
        if request.method == 'DELETE':
            if x.orders: return error('Pelanggan masih memiliki pesanan dan tidak dapat dihapus', 409)
            db.session.delete(x); db.session.commit(); return jsonify({'message':'Pelanggan berhasil dihapus'})
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if request.method == 'PUT' and required(d, ['name','email']): return error('PUT wajib mengirim name dan email', 400)
        if 'name' in d: x.name = str(d['name']).strip()
        if 'email' in d: x.email = str(d['email']).strip().lower()
        if 'phone' in d: x.phone = d['phone']
        return save_and_return(x)

    # Orders and nested order items
    @app.get('/orders')
    def orders_list(): return jsonify({'data': [x.to_dict() for x in Order.query.order_by(Order.id).all()]})
    @app.post('/orders')
    def orders_create():
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if required(d, ['customer_id']): return error('Field customer_id wajib diisi', 400)
        try: cid = int(d['customer_id'])
        except (ValueError, TypeError): return error('customer_id harus integer', 400)
        if not db.session.get(Customer, cid): return error('Pelanggan tidak ditemukan', 404)
        status = d.get('status', 'pending')
        if status not in ['pending','paid','shipped','completed','cancelled']: return error('status tidak valid', 400)
        return save_and_return(Order(customer_id=cid, status=status), 201)
    @app.route('/orders/<int:item_id>', methods=['GET','PUT','PATCH','DELETE'])
    def orders_item(item_id):
        x = db.session.get(Order, item_id)
        if not x: return error('Pesanan tidak ditemukan', 404)
        if request.method == 'GET': return jsonify({'data': x.to_dict()})
        if request.method == 'DELETE': db.session.delete(x); db.session.commit(); return jsonify({'message':'Pesanan berhasil dihapus'})
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if request.method == 'PUT' and required(d, ['customer_id','status']): return error('PUT wajib mengirim customer_id dan status', 400)
        if 'customer_id' in d:
            try: cid = int(d['customer_id'])
            except (ValueError, TypeError): return error('customer_id harus integer', 400)
            if not db.session.get(Customer, cid): return error('Pelanggan tidak ditemukan', 404)
            x.customer_id = cid
        if 'status' in d:
            if d['status'] not in ['pending','paid','shipped','completed','cancelled']: return error('status tidak valid', 400)
            x.status = d['status']
        return save_and_return(x)

    @app.get('/order-items')
    def order_items_list(): return jsonify({'data': [x.to_dict() for x in OrderItem.query.order_by(OrderItem.id).all()]})
    @app.post('/order-items')
    def order_items_create():
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if required(d, ['order_id','book_id','quantity']): return error('Field order_id, book_id, dan quantity wajib diisi', 400)
        try: oid, bid = int(d['order_id']), int(d['book_id'])
        except (ValueError, TypeError): return error('order_id dan book_id harus integer', 400)
        qty = d['quantity']
        if not isinstance(qty, int) or isinstance(qty, bool) or qty < 1: return error('quantity harus integer minimal 1', 400)
        order, book = db.session.get(Order, oid), db.session.get(Book, bid)
        if not order: return error('Pesanan tidak ditemukan', 404)
        if not book: return error('Buku tidak ditemukan', 404)
        if book.stock < qty: return error('Stok buku tidak mencukupi', 400)
        book.stock -= qty
        return save_and_return(OrderItem(order_id=oid, book_id=bid, quantity=qty, unit_price=book.price), 201)
    @app.route('/order-items/<int:item_id>', methods=['GET','PUT','PATCH','DELETE'])
    def order_items_item(item_id):
        x = db.session.get(OrderItem, item_id)
        if not x: return error('Item pesanan tidak ditemukan', 404)
        if request.method == 'GET': return jsonify({'data': x.to_dict()})
        if request.method == 'DELETE':
            x.book.stock += x.quantity; db.session.delete(x); db.session.commit(); return jsonify({'message':'Item pesanan dihapus dan stok dikembalikan'})
        d = body()
        if d is None: return error('Body harus berupa JSON object', 400)
        if request.method == 'PUT' and required(d, ['order_id','book_id','quantity']): return error('PUT wajib mengirim order_id, book_id, quantity', 400)
        new_qty = d.get('quantity', x.quantity)
        if not isinstance(new_qty, int) or isinstance(new_qty, bool) or new_qty < 1: return error('quantity harus integer minimal 1', 400)
        # Keep the order and book fixed for updates to avoid accidental stock/accounting inconsistencies.
        delta = new_qty - x.quantity
        if delta > x.book.stock: return error('Stok buku tidak mencukupi', 400)
        x.book.stock -= delta
        x.quantity = new_qty
        return save_and_return(x)

    def save_and_return(obj, status=200):
        try:
            db.session.add(obj); db.session.commit()
            return jsonify({'message':'Data berhasil disimpan', 'data':obj.to_dict()}), status
        except IntegrityError:
            db.session.rollback(); return jsonify({'status':'error','message':'Data duplikat atau melanggar relasi database'}), 409
        except Exception:
            db.session.rollback(); app.logger.exception('Gagal menyimpan data')
            return jsonify({'status':'error','message':'Terjadi kesalahan pada server'}), 500

    @app.errorhandler(404)
    def not_found(_): return jsonify({'status':'error','message':'Endpoint tidak ditemukan'}), 404
    @app.errorhandler(405)
    def method_not_allowed(_): return jsonify({'status':'error','message':'Method HTTP tidak diizinkan untuk endpoint ini'}), 405
    with app.app_context(): db.create_all()
    return app

app = create_app()

if __name__ == '__main__':
    app.run(debug=os.getenv('FLASK_DEBUG', 'false').lower() == 'true', port=int(os.getenv('PORT', '5000')))
