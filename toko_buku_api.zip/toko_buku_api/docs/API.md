# Dokumentasi API — Toko Buku

Base URL lokal: `http://127.0.0.1:5000`. Setelah deploy, ganti dengan URL Vercel milik sendiri.
Semua request dengan body menggunakan header `Content-Type: application/json`.

## Format respons
- Sukses: `{"data": {...}}` atau `{"message":"Data berhasil disimpan","data":{...}}`
- Error: `{"status":"error","message":"..."}`

## Endpoint
| Method | URL | Fungsi |
|---|---|---|
| GET | `/` | Info API |
| GET | `/health` | Health check |
| GET | `/categories` | Semua kategori |
| POST | `/categories` | Tambah kategori; body `{"name":"Pemrograman","description":"Buku coding"}` |
| GET | `/categories/{id}` | Detail kategori |
| PUT/PATCH | `/categories/{id}` | Ganti/ubah kategori |
| DELETE | `/categories/{id}` | Hapus kategori beserta buku terkait |
| GET | `/books` | Semua buku; filter opsional `?q=python&category_id=1` |
| POST | `/books` | Tambah buku; body contoh di bawah |
| GET | `/books/{id}` | Detail buku |
| PUT | `/books/{id}` | Ganti semua field buku |
| PATCH | `/books/{id}` | Ubah sebagian field buku |
| DELETE | `/books/{id}` | Hapus buku jika belum ada di item pesanan |
| GET | `/customers` | Semua pelanggan |
| POST | `/customers` | Tambah pelanggan; body `{"name":"Dina","email":"dina@example.com","phone":"08123456789"}` |
| GET/PUT/PATCH/DELETE | `/customers/{id}` | Detail, ubah, atau hapus pelanggan |
| GET | `/orders` | Semua pesanan beserta item dan total |
| POST | `/orders` | Buat pesanan; body `{"customer_id":1,"status":"pending"}` |
| GET/PUT/PATCH/DELETE | `/orders/{id}` | Detail, ubah status/pelanggan, atau hapus pesanan |
| GET | `/order-items` | Semua item pesanan |
| POST | `/order-items` | Tambah item; body `{"order_id":1,"book_id":1,"quantity":2}` |
| GET/PUT/PATCH/DELETE | `/order-items/{id}` | Detail, ubah jumlah, atau hapus item |

## Contoh request POST /books
```json
{
  "title": "Belajar Python",
  "author": "Ani",
  "price": 85000,
  "stock": 10,
  "category_id": 1
}
```
Contoh sukses `201 Created`:
```json
{
  "message": "Data berhasil disimpan",
  "data": {
    "id": 1,
    "title": "Belajar Python",
    "author": "Ani",
    "price": 85000.0,
    "stock": 10,
    "category_id": 1,
    "category": "Pemrograman"
  }
}
```

## Kode status
- `200`: berhasil
- `201`: data baru berhasil dibuat
- `400`: body atau input tidak valid
- `404`: resource tidak ditemukan
- `405`: method tidak diizinkan
- `409`: data duplikat atau operasi bertentangan dengan relasi
- `500`: kesalahan server tidak terduga

## Relasi database
1. `categories` satu-ke-banyak `books`.
2. `customers` satu-ke-banyak `orders`.
3. `orders` satu-ke-banyak `order_items`.
4. `books` satu-ke-banyak `order_items`.
5. `order_items` menjadi tabel penghubung pesanan dan buku; harga saat pemesanan disimpan di `unit_price`.

Diagram ERD tersedia di `dbdiagram.dbml`; buka https://dbdiagram.io lalu pilih Import > DBML dan tempel isi file tersebut untuk menghasilkan gambar ERD.
