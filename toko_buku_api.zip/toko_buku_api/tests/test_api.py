import pytest
from app import create_app, db

@pytest.fixture()
def client(tmp_path):
    database = tmp_path / 'test.db'
    app = create_app({'TESTING': True, 'SQLALCHEMY_DATABASE_URI': f'sqlite:///{database}'})
    with app.test_client() as client:
        yield client
    with app.app_context():
        db.drop_all()

def test_health(client):
    response = client.get('/health')
    assert response.status_code == 200
    assert response.json['status'] == 'ok'

def test_book_crud(client):
    category = client.post('/categories', json={'name':'Pemrograman'})
    assert category.status_code == 201
    category_id = category.json['data']['id']
    created = client.post('/books', json={'title':'Belajar Python','author':'Ani','price':85000,'stock':5,'category_id':category_id})
    assert created.status_code == 201
    book_id = created.json['data']['id']
    assert client.get(f'/books/{book_id}').status_code == 200
    updated = client.patch(f'/books/{book_id}', json={'stock':7})
    assert updated.status_code == 200 and updated.json['data']['stock'] == 7
    deleted = client.delete(f'/books/{book_id}')
    assert deleted.status_code == 200
    assert client.get(f'/books/{book_id}').status_code == 404

def test_validation_and_not_found(client):
    assert client.post('/books', json={'title':'Tidak lengkap'}).status_code == 400
    assert client.get('/books/999').status_code == 404
