# Toko Buku REST API

REST API backend untuk pengelolaan toko buku sederhana, dibuat menggunakan Python, Flask, Flask-SQLAlchemy, dan PostgreSQL. Struktur dibuat terinspirasi dari pola project Flask REST API contoh yang diberikan, tetapi tema dan implementasi disusun untuk tugas akhir ini.

## Fitur
- 5 tabel relasional dengan primary key dan foreign key.
- CRUD lengkap untuk resource utama `books`.
- Endpoint kategori, pelanggan, pesanan, dan item pesanan.
- JSON request/response, validasi input, serta HTTP status code.
- Pengurangan stok saat item pesanan dibuat dan pengembalian stok saat item dihapus.
- Filter buku berdasarkan judul atau kategori.
- File collection Postman dan unit test.
- Siap dikonfigurasi untuk deployment Vercel dengan PostgreSQL online.

## Skema database
- `categories` → `books`
- `customers` → `orders`
- `orders` → `order_items`
- `books` → `order_items`

Lihat `dbdiagram.dbml` dan `docs/API.md` untuk ERD dan dokumentasi endpoint.

## Menjalankan di Windows
1. Install Python 3.11 atau lebih baru.
2. Ekstrak project, buka terminal pada folder project.
3. Buat virtual environment:
   ```powershell
   py -m venv .venv
   .venv\Scripts\activate
   ```
4. Install library:
   ```powershell
   pip install -r requirements.txt
   ```
5. Salin `.env.example` menjadi `.env`. Untuk lokal, SQLite langsung dipakai secara default. Jika ingin membaca `.env` otomatis, install `python-dotenv` dan tambahkan `load_dotenv()` pada awal `app.py`; atau atur `DATABASE_URL` pada environment terminal. Jangan commit file `.env`.
6. Jalankan:
   ```powershell
   python app.py
   ```
7. Coba `http://127.0.0.1:5000/health`.

## Uji otomatis
```powershell
pytest -v
```

## Pengujian melalui Postman / Thunder Client
Import `postman_collection.json` ke Postman. Collection memakai variable `base_url` yang default-nya `http://127.0.0.1:5000`. Setelah deployment, ubah variable menjadi URL Vercel kamu. Jalankan request berurutan: create category → create book → get books → create customer → create order → create order item. Untuk bukti tugas, simpan screenshot request dan response setiap endpoint setelah diuji di URL deployment.

## Deploy ke Vercel
1. Buat database PostgreSQL online di Supabase atau Neon.
2. Salin connection string PostgreSQL. Jangan memasukkannya ke source code atau commit ke GitHub.
3. Upload project ke repository GitHub milikmu.
4. Di Vercel, pilih **Add New → Project**, import repository, lalu tambahkan Environment Variable `DATABASE_URL` berisi connection string PostgreSQL. Jika provider memberi URL `postgres://`, aplikasi mengubahnya menjadi `postgresql://`.
5. Deploy. Vercel mendeteksi Flask dari instance `app` di `app.py`; `vercel.json` tersedia sebagai konfigurasi project.
6. Uji URL publik `/health`, lalu uji semua endpoint lewat collection Postman dengan `base_url` URL Vercel.

Catatan: tabel dibuat otomatis saat aplikasi mulai. Pastikan database PostgreSQL bisa diakses dari Vercel dan gunakan connection string yang disarankan provider. URL deployment dan bukti uji tidak dapat diisi sebelum deployment milikmu tersedia.

## Keamanan
- Jangan mengunggah `.env`, password database, atau secret.
- Project ini merupakan contoh akademik, belum memakai autentikasi/otorisasi. Jangan gunakan untuk menyimpan data pelanggan sungguhan sebelum menambahkan kontrol akses dan pengamanan tambahan.

## Referensi
- Repository pola contoh: https://github.com/muhamadafif87/FlaskRESTAPI/
- Dokumentasi Flask di Vercel: https://vercel.com/docs/frameworks/backend/flask
